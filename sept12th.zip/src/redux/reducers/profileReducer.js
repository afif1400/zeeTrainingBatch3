// profile related details
// currentProfileDetails
// allProfileDetails
// github repos
// loading status

import {
  CLEAR_PROFILE,
  GET_PROFILE,
  GET_PROFILES,
  PROFILE_ERROR,
  UPDATE_PROFILE,
} from "../types";

// error details
const initialState = {
  profile: null, // current profile
  profiles: [], // list of profiles / all profiles
  repos: [], // list of repos
  loading: true, //
  error: {},
};

export default (state = initialState, action) => {
  const { type, payload } = action;
  switch (type) {
    case UPDATE_PROFILE:
    case GET_PROFILE:
      return { ...state, profile: payload, loading: false };
    case PROFILE_ERROR:
      return { ...state, error: payload, loading: false, profile: null };

    case CLEAR_PROFILE:
      return {
        ...state,

        loading: false,
        profile: null,
        repos: [],
      };
    case GET_PROFILES:
      return { ...state, profiles: payload, loading: false };

    default:
      return state;
  }
};
