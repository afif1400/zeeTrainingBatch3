import PropTypes from "prop-types";
import React from "react";
import { connect } from "react-redux";

const Alert = ({ alerts }) =>
  alerts !== null &&
  alerts.length > 0 &&
  alerts.map((alert) => (
    <div key={alert.id} className={`alert alert-${alert.alertType}`}>
      {alert.msg}
    </div>
  ));
// will be displayed N number of times.
// which one we need to remove after 5 sec r?

// manipulate the array & internally it will traverse the array and on every iteration it will give us the array element to manipulate the data array

Alert.propTypes = { alerts: PropTypes.array.isRequired };

const mapStateToProps = (state) => ({
  alerts: state.alerts, // state : store ( mapping )
});

//const mapDispatchToProps = {}; // are we consuming any action : No

export default connect(mapStateToProps)(Alert);
