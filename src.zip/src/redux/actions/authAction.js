import axios from "axios";
import { headerConfig } from "../../utils/commonConfig";
import { REGISTER_FAIL, REGISTER_SUCCESS } from "../types";
import { setAlert } from "./alertAction";
export const register =
  ({ name, email, password }) =>
  async (dispatch) => {
    //action story
    // rest call action
    // axios call
    const data = JSON.stringify({ name, email, password });

    try {
      const res = await axios.post("/api/users", data, headerConfig);
      dispatch({ type: REGISTER_SUCCESS, payload: res.data });
    } catch (err) {
      const { errors } = err.response.data;
      // errors : its an array of errors
      if (errors) {
        // errors !null means
        errors.forEach((err) => dispatch(setAlert(err.msg, "danger")));
      }

      dispatch({ type: REGISTER_FAIL });

      // errors ===> error details for every field ===> we need to display it to user screen
      // these details one by one can we share it to the alert user
      // these details we will share it to alert by calling its alert action on the

      // alert action will set the details into store via reducer ==> details will be displayed by component(alert )
    }
    // url
    // success part then method call ==> we have to share the details to make some changes to ur store as per the action.

    // failure catch method call ==> we have to share the failure details to make some changes to ur store as per the action
    // success/ failure action details includes 2 parts 1. type
    // 2. payload (data to be inserted / manipulate/deleted ) from the store.
  };
