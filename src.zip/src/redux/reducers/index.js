// we have to make the entries of all available reducers @ one place ===> index.js from reducers folder
// we have register all the reducers
// by adding them to combineReducers method.
import { combineReducers } from "redux";
import auth from "./authReducer";
import alerts from "./alertReducer";
export default combineReducers({ auth, alerts });
