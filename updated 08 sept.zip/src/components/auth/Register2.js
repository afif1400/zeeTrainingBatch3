import React, { useState } from "react";
import classnames from "classnames";
import axios from "axios";
// hook : useState ---> state from CBC
export const Register2 = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    password2: "",
  });

  const [errors, setErrors] = useState({});

  const { name, email, password, password2 } = formData;

  const errorObj = {};
  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  const onSubmit = (e) => {
    e.preventDefault();
    console.log("hello from abhi");
    // axios
    //   .post("/api/users", { name, email, password })

    //   .then((res) => console.log(JSON.stringify(res))) // success
    //   .catch((err) => {
    //     // console.log(JSON.stringify(err.response.data));

    //     err.response.data.errors.forEach((e) => {
    //       console.log(JSON.stringify(e));
    //       if (e.param == "email") {
    //         errorObj.email = e.msg;
    //       }
    //       if (e.param == "password") {
    //         errorObj.password = e.msg;
    //       }
    //     });
    //     console.log(JSON.stringify(errorObj));
    //     //this.setState({ errorObj: errorObj });

    //     setErrors({ ...errorObj });
    //   });
  };

  return (
    <div>
      {" "}
      <section class="container">
        <h1 class="large text-primary">Sign Up</h1>
        <p class="lead">
          <i class="fas fa-user"></i> Create Your Account
        </p>
        <form class="form" onSubmit={onSubmit}>
          <div class="form-group">
            <input
              type="text"
              placeholder="Name"
              name="name"
              value={name}
              onChange={onChange}
            />
          </div>
          <div class="form-group">
            <input
              type="email"
              placeholder="Email Address"
              name="email"
              value={email}
              onChange={onChange}
            />
            <div>{errorObj.email}</div>
            <small class="form-text">
              This site uses Gravatar so if you want a profile image, use a
              Gravatar email
            </small>
          </div>
          <div class="form-group">
            <input
              type="password"
              placeholder="Password"
              name="password"
              minLength="6"
              value={password}
              onChange={onChange}
              className={classnames("form-control form-control-lg", {
                "is-invalid": errorObj.password,
              })}
            />
            <div
              className="d-block 
        
        invalid-feedback"
            >
              {errorObj.password}
            </div>
          </div>
          <div class="form-group">
            <input
              type="password"
              placeholder="Confirm Password"
              name="password2"
              minLength="6"
              value={password2}
              onChange={onChange}
            />
          </div>
          <input type="submit" class="btn btn-primary" value="Register" />
        </form>
        <p class="my-1">
          Already have an account? <a href="login.html">Sign In</a>
        </p>
      </section>
    </div>
  );

  return <div>Register2</div>;
};
