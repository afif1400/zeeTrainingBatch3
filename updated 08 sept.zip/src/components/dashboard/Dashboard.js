import PropTypes from "prop-types";
import React, { useEffect } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { getCurrentProfile } from "../../redux/actions/profileAction";
import DashboardAction from "./DashboardAction";
import DisplayEducation from "./DisplayEducation";
import DisplayExperience from "./DisplayExperience";

// user details : user from auth combineReducers
// profile : profile details from profile reducer.
//based on the token we need to retreive the currentProfileDetails ==> exp and edu details
// inside the dashboard ==> we are getting exp and edu details then are we suppose to do a rest call to get all details about exp and edu ?
// No ---> how to share the details? ==> can we use props?==> yes ==> exp and edu details component should connect to redux store?
// all exp and edu details we will get it in terms of json array
// we have to traverse the respective array in the component

const Dashboard = ({
  auth: { user },
  getCurrentProfile,
  profile: { profile }, // profile: {currentProfile : profile} / {profile}
}) => {
  // when the component is rendered 1st time or updated (anytime)
  // useEffect
  useEffect(() => {
    getCurrentProfile();
  }, [getCurrentProfile]);

  const profileStatus = null;
  const existingProfile = (
    <>
      {" "}
      <DashboardAction />
      <DisplayExperience></DisplayExperience>
      <DisplayEducation></DisplayEducation>
      <div className="my-2">
        <button className="btn btn-danger" onClick={() => true}>
          <i className="fas fa-user-minus" /> Delete My Account
        </button>
      </div>
    </>
  );
  const createProfile = (
    <>
      <p>You have not yet setup a profile, please add some info</p>
      <Link to="/create-profile" className="btn btn-primary my-1">
        Create Profile
      </Link>
    </>
  );
  return (
    <section className="container">
      <h1 className="large text-primary">Dashboard</h1>
      <p className="lead">
        <i className="fas fa-user" /> Welcome {user && user.name}
      </p>
      {profile == null ? createProfile : existingProfile}
    </section>
  );
};

Dashboard.propTypes = {
  auth: PropTypes.object.isRequired,
  getCurrentProfile: PropTypes.func.isRequired,
  profile: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => ({
  auth: state.auth,
  profile: state.profile,
});

const mapDispatchToProps = { getCurrentProfile };

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
