import React from "react";

export const Login2 = () => {
  return <div>Login2</div>;
};
