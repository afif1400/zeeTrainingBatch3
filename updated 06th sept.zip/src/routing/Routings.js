import React, { Fragment, useState } from "react";
import { Link, Redirect } from "react-router-dom";
import { Route, Routes, BrowserRouter as Router } from "react-router-dom";
// import Login from "../components/auth/Login";
import { Login2 } from "../components/auth/Login2";
import Login3 from "../components/auth/Login3";
// import Register from "../components/auth/Register";
import { Register2 } from "../components/auth/Register2";
import Register3 from "../components/auth/Register3";
import Alert from "../components/common/Alert";
import Landing from "../components/layouts/Landing";
export const Routings = () => {
  return (
    <div>
      <Alert></Alert>
      <Routes>
        <Route path="/" element={<Landing></Landing>}></Route>
        <Route path="login" element={<Login3 />}></Route>
        <Route path="register" element={<Register3 />}></Route>
      </Routes>
    </div>
  );
};
