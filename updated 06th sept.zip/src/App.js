import logo from "./logo.svg";
import "./App.css";

import { Navbar } from "./components/layouts/Navbar";
import Footer from "./components/layouts/Footer";
import { BrowserRouter as Router, withRouter } from "react-router-dom";
import { Routings } from "./routing/Routings";
import { Provider } from "react-redux";
import store from "./redux/store";
function App() {
  const appName = "devConnector";
  return (
    // render method
    <Provider store={store}>
      <div className="App">
        <Router>
          <Navbar appName={appName}></Navbar>
          <Routings />
          <Footer></Footer>
        </Router>
      </div>
    </Provider>
  );
}

export default App;
