import React, { Fragment, useState } from "react";
import { Link, Redirect } from "react-router-dom";
import { Route, Routes, BrowserRouter as Router } from "react-router-dom";
// import Login from "../components/auth/Login";
import { Login2 } from "../components/auth/Login2";
import Login3 from "../components/auth/Login3";
// import Register from "../components/auth/Register";
import { Register2 } from "../components/auth/Register2";
import Register3 from "../components/auth/Register3";
import Alert from "../components/common/Alert";
import Dashboard from "../components/dashboard/Dashboard";
import Landing from "../components/layouts/Landing";
import AddExperience from "../components/Profile/AddExperience";
import CreateProfile from "../components/Profile/CreateProfile";
import Profiles from "../components/profiles/Profiles";
import PrivateRoute from "./PrivateRoute";
export const Routings = () => {
  return (
    <div>
      <Alert></Alert>
      <Routes>
        <Route path="/" element={<Landing></Landing>}></Route>
        <Route path="login" element={<Login3 />}></Route>
        <Route path="register" element={<Register3 />}></Route>
        <Route
          path="dashboard"
          element={<PrivateRoute component={Dashboard}></PrivateRoute>}
        ></Route>
        <Route
          path="create-profile"
          element={<PrivateRoute component={CreateProfile}></PrivateRoute>}
        ></Route>
        <Route
          path="edit-profile"
          element={<PrivateRoute component={CreateProfile}></PrivateRoute>}
        ></Route>
        <Route
          path="add-experience"
          element={<PrivateRoute component={AddExperience}></PrivateRoute>}
        ></Route>
        <Route path="profiles" element={<Profiles></Profiles>}></Route>
      </Routes>
    </div>
  );
};
