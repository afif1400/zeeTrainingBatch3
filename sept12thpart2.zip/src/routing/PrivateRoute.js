import PropTypes from "prop-types";
import React from "react";
import { connect } from "react-redux";
import Spinner from "../components/common/Spinner";

// this one is the decision maker to allow to render the component or not?

const PrivateRoute = ({
  component: Component,
  auth: { isAuthenticated, loading },
}) =>
  // component : name of the component to confirm teh access to render
  // auth : name of the reduer from the store
  // loading : status to render the spinner component
  // isAuthenticated : to give the direct access to render the component
  {
    if (loading) {
      return <Spinner />;
    }
    if (isAuthenticated) {
      return <Component></Component>;
    }
  };

PrivateRoute.propTypes = {
  auth: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => ({
  auth: state.auth,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(PrivateRoute);
