import PropTypes from "prop-types";
import React from "react";
import { connect } from "react-redux";

const ViewProfile = (props) => {
  return <div>ViewProfile</div>;
};

ViewProfile.propTypes = {
  second: PropTypes.third,
};

const mapStateToProps = (state) => ({});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(ViewProfile);
