import axios from "axios";
import api from "../../utils/api";
import { headerConfig } from "../../utils/commonConfig";
import setAuthToken from "../../utils/setAuthToken";
import {
  LOGIN_FAIL,
  LOGIN_SUCCESS,
  REGISTER_FAIL,
  REGISTER_SUCCESS,
  USER_LOADED,
} from "../types";
import { setAlert } from "./alertAction";

export const loadUser = () => async (dispatch) => {
  if (localStorage.token) {
    setAuthToken(localStorage.token);
  }
  try {
    const res = await api.get("/auth");
    dispatch({ type: USER_LOADED, payload: res.data });
  } catch (err) {}

  // end point : /api/auth
  // if token is available in the localStorage then use the token to get the details
  // if not throw the error?
};

export const register =
  ({ name, email, password }) =>
  async (dispatch) => {
    //action story
    // rest call action
    // axios call
    const data = JSON.stringify({ name, email, password });

    try {
      const res = await api.post("/users", data, headerConfig);
      dispatch({ type: REGISTER_SUCCESS, payload: res.data });
      dispatch(loadUser());
    } catch (err) {
      const { errors } = err.response.data;
      // errors : its an array of errors
      if (errors) {
        // errors !null means
        errors.forEach((err) => dispatch(setAlert(err.msg, "danger")));
      }

      dispatch({ type: REGISTER_FAIL });

      // errors ===> error details for every field ===> we need to display it to user screen
      // these details one by one can we share it to the alert user
      // these details we will share it to alert by calling its alert action on the

      // alert action will set the details into store via reducer ==> details will be displayed by component(alert )
    }
    // url
    // success part then method call ==> we have to share the details to make some changes to ur store as per the action.

    // failure catch method call ==> we have to share the failure details to make some changes to ur store as per the action
    // success/ failure action details includes 2 parts 1. type
    // 2. payload (data to be inserted / manipulate/deleted ) from the store.
  };

export const login = (email, password) => async (dispatch) => {
  // rest call   ==> we have to share the details to make some changes to ur store as
  // end point : /api/auth

  try {
    const body = JSON.stringify({ email, password });
    const res = await api.post("/auth", body, headerConfig);
    dispatch({ type: LOGIN_SUCCESS, payload: res.data });
    dispatch(loadUser());
  } catch (err) {
    const errors = err.response.data.errors;

    if (errors) {
      errors.forEach((error) => dispatch(setAlert(error.msg, "danger")));
    }

    dispatch({
      type: LOGIN_FAIL,
    });
  }
};
