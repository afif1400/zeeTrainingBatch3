package com.boraji.tutorail.spring;

/**
 * @author imssbora
 */
public interface Shape {
   void draw();
}
