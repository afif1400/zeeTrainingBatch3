package com.boraji.tutorial.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.boraji.tutorial.spring.bean.BeanA;
import com.boraji.tutorial.spring.bean.BeanB;
import com.boraji.tutorial.spring.bean.BeanC;
import com.boraji.tutorial.spring.config.ConfigC;

/**
 * @author imssbora
 */
public class MainApp {
   public static void main(String[] args) {
      AnnotationConfigApplicationContext context = 
            new AnnotationConfigApplicationContext(ConfigC.class);

      BeanA beanA=context.getBean(BeanA.class);
      beanA.doSomething();
      
      BeanB beanB=context.getBean(BeanB.class);
      beanB.doSomething();
      
      BeanC beanC=context.getBean(BeanC.class);
      beanC.doSomething();
      
      context.close();
   }
}
