package com.boraji.tutorial.spring.bean;

public class BeanB {
   public void doSomething(){
      System.out.println("Inside doSomething() method of BeanB");
   }
}
