package com.boraji.tutorial.spring.bean;

public class BeanA {
   public void doSomething(){
      System.out.println("Inside doSomething() method of BeanA");
   }
}
