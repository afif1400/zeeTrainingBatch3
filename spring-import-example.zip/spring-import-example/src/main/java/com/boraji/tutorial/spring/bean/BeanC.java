package com.boraji.tutorial.spring.bean;

public class BeanC {
   public void doSomething(){
      System.out.println("Inside doSomething() method of BeanC");
   }
}
