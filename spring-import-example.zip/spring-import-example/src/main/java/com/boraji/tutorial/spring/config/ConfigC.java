package com.boraji.tutorial.spring.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;

import com.boraji.tutorial.spring.bean.BeanC;

/**
 * @author imssbora
 */
@Configuration
@Import(value={ConfigA.class})
@ImportResource(locations={
      "classpath:/com/boraji/tutorial/spring/config/configB.xml"
     })
public class ConfigC {
   @Bean
   public BeanC getBeanC() {
      return new BeanC();
   }
}
