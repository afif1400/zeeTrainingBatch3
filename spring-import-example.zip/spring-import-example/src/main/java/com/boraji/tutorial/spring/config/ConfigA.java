package com.boraji.tutorial.spring.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.boraji.tutorial.spring.bean.BeanA;

/**
 * @author imssbora
 */
@Configuration
public class ConfigA {
   @Bean
   public BeanA getBeanA(){
      return new BeanA();
   }
}
